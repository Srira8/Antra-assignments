﻿using System;

class Program
{
    static void Main()
    {
        // Step 1: Create an initial array with 10 elements
        int[] originalArray = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };

        // Step 2: Create a second array with the same length as the original
        int[] copiedArray = new int[originalArray.Length];

        // Step 3: Copy elements using a loop
        for (int i = 0; i < originalArray.Length; i++)
        {
            copiedArray[i] = originalArray[i];
        }

        // Step 4: Print both arrays to verify copying
        Console.WriteLine("Original Array: " + string.Join(", ", originalArray));
        Console.WriteLine("Copied Array: " + string.Join(", ", copiedArray));

        // Test FindPrimesInRange from PrimeMethods
        Console.WriteLine("\nFinding primes between 10 and 50:");
        int[] primes = PrimeMethods.FindPrimesInRange(10, 50);
        Console.WriteLine("Prime numbers: " + string.Join(", ", primes));

        // Step 5: Invoke the RotateAndSum method from ArrayRotation class
        Console.WriteLine("\nRotating and summing the array:");
        ArrayRotation.RotateAndSum(originalArray, 3);  // Rotate 3 times for demonstration

        // Step 6: Invoke the FindLongestSequence method
        Console.WriteLine("\nFinding the longest sequence of equal elements:");
        int[] testArray = { 2, 1, 1, 2, 3, 3, 2, 2, 2, 1 };
        LongestSequenceFinder.FindLongestSequence(testArray);

        // Step 7: Invoke the FindMostFrequent method
        Console.WriteLine("\nFinding the most frequent number:");
        int[] frequencyArray = { 4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3 };
        MostFrequentNumberFinder.FindMostFrequentNumber(frequencyArray);

        // Step 8: String reversal using combined methods
        Console.WriteLine("\nEnter a string to reverse:");
        string input = Console.ReadLine();
        StringReverser.ReverseString(input);

        // Step 9: Reverse words in sentence while maintaining punctuation
        Console.WriteLine("\nEnter a sentence to reverse words (punctuation intact):");
        string sentence = Console.ReadLine();
        SentenceReverser.ReverseWordsInSentence(sentence);

        // Step 10: Extract palindromes from the text
        Console.WriteLine("\nEnter a text to extract palindromes:");
        string text = Console.ReadLine();
        PalindromeExtractor.ExtractPalindromes(text);

        // Step 11: Parse a URL
        Console.WriteLine("\nEnter a URL to parse:");
        string url = Console.ReadLine();
        UrlParser.ParseUrl(url);

        // Start ListManager
        Console.WriteLine("\nStarting ListManager...");
        ListManager listManager = new ListManager();
        listManager.Run();
    }
}
